import assert from "node:assert/strict";
import { test } from "node:test";
import { buildApp } from "../src/app.js";
import { MemoryRepository } from "../src/repository.js";

const headers={"x-user-id":"ops_karthik","x-role":"operations","x-city-id":"blr"};

test("health endpoint",async()=>{const app=buildApp(new MemoryRepository());const response=await app.inject({method:"GET",url:"/health"});assert.equal(response.statusCode,200);assert.equal(response.json().status,"ok");await app.close();});

test("search masks customer number for operations",async()=>{const app=buildApp(new MemoryRepository());const response=await app.inject({method:"GET",url:"/v1/customers?q=Meera",headers});assert.equal(response.statusCode,200);assert.match(response.json().data[0].primaryPhone,/•/);await app.close();});

test("creates an idempotent assisted booking and auto assigns full-time provider",async()=>{const repository=new MemoryRepository();await repository.upsertAvailability({id:"a1",providerId:"pro_arjun",cityId:"blr",zoneId:"blr-east",date:"2026-08-08",windows:["09:00-19:00"],source:"roster",updatedAt:new Date().toISOString()});const app=buildApp(repository);const payload={customerId:"cus_10428",petIds:["pet_bruno"],serviceCode:"grooming",packageCode:"bath_basic",addonCodes:[],zoneId:"blr-east",scheduledStart:"2026-08-08T03:30:00.000Z",scheduledEnd:"2026-08-08T05:30:00.000Z",channel:"operations_assisted"};const first=await app.inject({method:"POST",url:"/v1/bookings",headers:{...headers,"idempotency-key":"booking-test-001"},payload});assert.equal(first.statusCode,201);assert.equal(first.json().data.totalAmount,1899);assert.equal(first.json().data.assignmentMode,"automatic");const second=await app.inject({method:"POST",url:"/v1/bookings",headers:{...headers,"idempotency-key":"booking-test-001"},payload});assert.equal(second.statusCode,200);assert.equal(second.json().meta.duplicatePrevented,true);await app.close();});

test("rejects assisted booking by customer role",async()=>{const app=buildApp(new MemoryRepository());const response=await app.inject({method:"POST",url:"/v1/bookings",headers:{"x-user-id":"cus_10428","x-role":"customer","x-city-id":"blr","idempotency-key":"booking-test-002"},payload:{customerId:"cus_10428",petIds:["pet_bruno"],serviceCode:"grooming",packageCode:"bath_basic",zoneId:"blr-east",scheduledStart:"2026-08-08T03:30:00.000Z",scheduledEnd:"2026-08-08T05:30:00.000Z",channel:"sales_assisted"}});assert.equal(response.statusCode,403);await app.close();});
