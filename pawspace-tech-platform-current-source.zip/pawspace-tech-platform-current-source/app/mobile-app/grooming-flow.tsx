"use client";
import { useState } from "react";
import styles from "./grooming-flow.module.css";
import { createTestTransaction } from "../../lib/test-transaction";
import ProviderTrackingCard from "./provider-tracking-card";
import CouponField from "./coupon-field";
import { reserveUatSchedule } from "../../lib/uat-scheduling-client";
import { createCanonicalLifecycle } from "../../lib/canonical-lifecycle-client";

type PetType = "dog" | "cat" | "puppy" | "kitten";
type Pack = {
  id: string;
  name: string;
  detail: string;
  price: number;
  badge: string;
  bestFor: string;
  includes: string[];
  missing: string[];
};
const dates = ["Today, 4 Aug", "Wed, 5 Aug", "Thu, 6 Aug", "Fri, 7 Aug"],
  slots = [
    "9:00–11:00 AM",
    "11:00 AM–1:00 PM",
    "1:00–3:00 PM",
    "3:00–5:00 PM",
    "5:00–7:00 PM",
  ];
const packages: Record<PetType, Pack[]> = {
  dog: [
    {
      id: "bath",
      name: "Essential Bath",
      detail: "A complete clean-up for regular coat care.",
      price: 1349,
      badge: "Fresh & clean",
      bestFor: "Routine freshness between full grooms",
      includes: ["Shampoo bath", "Deshedding", "Blow dry", "Coat brushing"],
      missing: [
        "Nail clipping",
        "Ear cleaning",
        "Teeth cleaning",
        "Hygiene trim",
        "Full haircut",
      ],
    },
    {
      id: "basic",
      name: "Bath & Basic",
      detail: "Bath plus the essential hygiene services.",
      price: 1899,
      badge: "Most booked",
      bestFor: "Monthly bath and hygiene maintenance",
      includes: [
        "Everything in Essential Bath",
        "Nail clipping",
        "Ear cleaning",
        "Teeth cleaning",
        "Minor hygiene trim",
      ],
      missing: ["Full-body haircut", "Breed styling"],
    },
    {
      id: "complete",
      name: "Complete Makeover",
      detail: "The complete bath, hygiene and styling service.",
      price: 2399,
      badge: "Everything included",
      bestFor: "Full grooming and a fresh styled finish",
      includes: [
        "Everything in Bath & Basic",
        "Full-body haircut",
        "Breed-appropriate styling",
        "Finishing and coat setting",
      ],
      missing: ["Tick & flea treatment", "Oil massage"],
    },
    {
      id: "trim",
      name: "Just Trim",
      detail: "Hair and hygiene tidy-up without a bath.",
      price: 1599,
      badge: "No bath",
      bestFor: "A quick haircut between bath appointments",
      includes: ["Full-body haircut", "Nail clipping", "Ear cleaning"],
      missing: ["Shampoo bath", "Deshedding", "Blow dry", "Teeth cleaning"],
    },
  ],
  cat: [
    {
      id: "routine",
      name: "Routine Grooming",
      detail: "Gentle dry grooming and hygiene care.",
      price: 1149,
      badge: "No bath",
      bestFor: "Cats needing regular coat and hygiene care",
      includes: [
        "Nail clipping",
        "Deshedding",
        "Teeth cleaning",
        "Ear cleaning",
        "Sanitary trim",
        "Combing",
      ],
      missing: ["Bath", "Blow dry", "Full haircut"],
    },
    {
      id: "basic",
      name: "Bath & Basic",
      detail: "Routine grooming plus a gentle bath.",
      price: 1899,
      badge: "Most booked",
      bestFor: "Complete bath and routine cat hygiene",
      includes: [
        "Everything in Routine Grooming",
        "Cat-safe bath",
        "Gentle massage",
        "Low-stress blow dry",
      ],
      missing: ["Full-body haircut", "Breed styling"],
    },
    {
      id: "complete",
      name: "Complete Makeover",
      detail: "Full cat grooming with haircut and styling.",
      price: 2399,
      badge: "Everything included",
      bestFor: "Long coats, matting care and a full reset",
      includes: [
        "Everything in Bath & Basic",
        "Full-body haircut",
        "Coat styling",
        "Finishing and comb-out",
      ],
      missing: ["Tick & flea treatment", "Oil massage"],
    },
    {
      id: "trim",
      name: "Just Trim",
      detail: "Hair and hygiene tidy-up without a bath.",
      price: 1599,
      badge: "No bath",
      bestFor: "A quick haircut when bathing is not needed",
      includes: ["Full-body haircut", "Nail clipping", "Ear cleaning"],
      missing: ["Bath", "Deshedding wash", "Blow dry", "Teeth cleaning"],
    },
  ],
  puppy: [
    {
      id: "basic",
      name: "Puppy Bath & Basic",
      detail: "A gentle first grooming experience.",
      price: 999,
      badge: "Up to 6 months",
      bestFor: "Safe introduction to grooming",
      includes: [
        "Puppy-safe bath",
        "Basic hygiene",
        "Gentle massage",
        "Low-heat drying",
        "Minor trim",
      ],
      missing: ["Full-body haircut", "Breed styling"],
    },
    {
      id: "complete",
      name: "Puppy Complete Makeover",
      detail: "Gentle full care with puppy-safe styling.",
      price: 1399,
      badge: "Everything included",
      bestFor: "A complete puppy groom",
      includes: [
        "Everything in Bath & Basic",
        "Full-body trim",
        "Puppy-safe styling",
        "Finishing brush",
      ],
      missing: ["Tick & flea treatment", "Oil massage"],
    },
  ],
  kitten: [
    {
      id: "basic",
      name: "Kitten Bath & Basic",
      detail: "A gentle first grooming experience.",
      price: 999,
      badge: "Up to 6 months",
      bestFor: "Safe introduction to grooming",
      includes: [
        "Kitten-safe bath",
        "Basic hygiene",
        "Gentle massage",
        "Low-stress drying",
        "Minor trim",
      ],
      missing: ["Full-body haircut", "Coat styling"],
    },
    {
      id: "complete",
      name: "Kitten Complete Makeover",
      detail: "Gentle full care with kitten-safe styling.",
      price: 1399,
      badge: "Everything included",
      bestFor: "A complete kitten groom",
      includes: [
        "Everything in Bath & Basic",
        "Full-body trim",
        "Coat styling",
        "Finishing comb-out",
      ],
      missing: ["Tick & flea treatment", "Oil massage"],
    },
  ],
};
const subs = [
  { id: "3", name: "3 sessions", price: 3597, validity: "4 months" },
  { id: "6", name: "6 sessions", price: 6594, validity: "8 months" },
  { id: "12", name: "12 sessions", price: 11988, validity: "15 months" },
  { id: "trim3", name: "Just Trim · 3", price: 4197, validity: "4 months" },
];
const money = (n: number) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(n);
function bundle(p: Pack, n: number, t: PetType) {
  if (n === 1) return p.price;
  if (t === "puppy" || t === "kitten") return p.price * n;
  if (p.id === "trim") return 1399 * n;
  const two: Record<string, number> = {
    "dog:bath": 2298,
    "cat:routine": 1998,
    "dog:basic": 3298,
    "cat:basic": 3298,
    "dog:complete": 4298,
    "cat:complete": 4298,
  };
  return two[`${t}:${p.id}`] ? (two[`${t}:${p.id}`] / 2) * n : p.price * n;
}
function subscriptionPrice(id: string, t: PetType, price: number) {
  return id === "3" && t === "cat" ? 2999 : price;
}

export default function GroomingFlow() {
  const [step, setStep] = useState(1),
    [type, setType] = useState<PetType>("dog"),
    [count, setCount] = useState(1),
    [packId, setPackId] = useState("bath"),
    [plan, setPlan] = useState("single"),
    [addons, setAddons] = useState<string[]>([]),
    [date, setDate] = useState(dates[1]),
    [slot, setSlot] = useState(slots[1]),
    [preferred, setPreferred] = useState(true),
    [pay, setPay] = useState("after"),
    [discount, setDiscount] = useState(0),
    [couponCode, setCouponCode] = useState(""),
    [done, setDone] = useState(false),
    [bookedId, setBookedId] = useState(""),
    [scheduling, setScheduling] = useState(false),
    [scheduleError, setScheduleError] = useState(""),
    [view, setView] = useState("status");
  const list = packages[type],
    pack = list.find((p) => p.id === packId) || list[0],
    sub = subs.find((s) => s.id === plan),
    addonTotal = addons.reduce(
      (n, a) => n + (a === "Tick & flea treatment" ? 499 : 299),
      0,
    ),
    subtotal =
      (sub
        ? subscriptionPrice(sub.id, type, sub.price) * count
        : bundle(pack, count, type)) + addonTotal,
    total = Math.max(0, subtotal - discount),
    duration =
      count <= 2
        ? "2-hour service window"
        : count === 3
          ? "2.5-hour service window"
          : "4-hour service window",
    summary = `${count} ${type}${count > 1 ? "s" : ""} · ${sub ? sub.name : pack.name}`;
  const changeType = (t: PetType) => {
      setType(t);
      setPackId(packages[t][0].id);
      setPlan("single");
    },
    toggle = (a: string) =>
      setAddons((x) => (x.includes(a) ? x.filter((v) => v !== a) : [...x, a])),
    confirm = async () => {
      setScheduling(true);setScheduleError("");
      try {
      const dateIndex=Math.max(0,dates.indexOf(date));const slotIndex=Math.max(0,slots.indexOf(slot));const start=new Date(Date.UTC(2026,7,4+dateIndex,3+slotIndex*2,30));const end=new Date(start.getTime()+(count>=4?240:count===3?150:120)*60_000);const petNames=["Bruno","Coco","Milo","Luna"].slice(0,count);const requestId=`groom-TST101-${dateIndex}-${slotIndex}-${count}`;const decision=await reserveUatSchedule({clientRequestId:requestId,customerId:"TST-101",petIds:petNames,serviceCode:"grooming",zoneId:"blr-east",scheduledStart:start.toISOString(),scheduledEnd:end.toISOString(),preferredProviderId:preferred?"groom_arun":undefined});
      const canonical=await createCanonicalLifecycle({idempotencyKey:requestId,scheduleGroupId:decision.groupId,customer:{id:"TST-101",name:"Karthik P.",primaryPhone:"9996999505",secondaryPhone:"9880222741"},pets:petNames.map(name=>({sourceId:name,name,species:name==="Coco"?"cat":"dog"})),cityId:"blr",zoneId:"blr-east",serviceCode:"grooming",packageCode:sub?`subscription-${sub.id}`:pack.id,packageName:sub?`${sub.name} grooming plan`:pack.name,scheduledStart:start.toISOString(),scheduledEnd:end.toISOString(),provider:decision.provider,totalAmount:total,amountDueNow:pay==="online"?total:0,payment:{method:pay==="online"?"upi":"cash",mode:pay==="online"?"prepaid":"pay_after_service",status:pay==="online"?"captured":"created",detail:pay==="online"?"UAT online payment captured":"Pay after service"},pricing:{discount,couponCode:couponCode||undefined,subscription:sub?.name}});
      const booking = createTestTransaction({
        customerId: "TST-101",
        customerName: "Karthik P.",
        primary: "9996999505",
        secondary: "9880222741",
        pets: ["Bruno", "Coco", "Milo", "Luna"].slice(0, count).join(", "),
        petCount: count,
        service: "Grooming",
        packageName: sub ? `${sub.name} grooming plan` : pack.name,
        area: "Bengaluru",
        slot: `${date} · ${slot}`,
        duration,
        amount: total,
        offerCode: couponCode || undefined,
        discount,
        payment: `${pay === "online" ? "Paid online" : "Pay after service"}${couponCode ? ` · Coupon ${couponCode}` : ""}`,
        provider: decision.provider.name,
        providerModel: decision.provider.model === "full_time" ? "Full-time" : "Commission",
        subscription: sub ? `${sub.name} · ${sub.validity}` : "No active plan",
        creditsBefore: sub ? Number.parseInt(sub.id) || 0 : 0,
        crmOwner: "Neha",
        crmNextAction: "Post-booking care follow-up",
        reminder: "Primary and secondary confirmations queued",
      },canonical.bookingId);
      setBookedId(booking.id);
      setDone(true);
      } catch(error){setScheduleError(error instanceof Error?error.message:"No groomer is available for this slot");} finally {setScheduling(false);}
    };
  if (done)
    return (
      <section className={styles.flow}>
        <article className={styles.success}>
          <i>✓</i>
          <small>BOOKING CONFIRMED · {bookedId}</small>
          <h3>Your groomer is reserved.</h3>
          <p>
            {summary} · {date} · {slot}
          </p>
        </article>
        <div className={styles.tabs}>
          {["status", "photos", "payment"].map((v) => (
            <button
              key={v}
              className={view === v ? styles.selected : ""}
              onClick={() => setView(v)}
            >
              {v[0].toUpperCase() + v.slice(1)}
            </button>
          ))}
        </div>
        {view === "status" && (
          <>
            <article className={styles.person}>
              <i>AR</i>
              <div>
                <span>AUTO-MATCHED · FULL-TIME TEAM</span>
                <b>Arun R. · 4.9 ★</b>
                <small>Identity verified · 842 completed services</small>
              </div>
              <button>Track ETA</button>
            </article>
            <ProviderTrackingCard role="Groomer" name="Arun R." eta="14 min" />
            <div className={styles.timeline}>
              <b>Confirmed</b>
              <i />
              <span>On the way</span>
              <i />
              <span>Service OTP</span>
              <i />
              <span>Complete</span>
            </div>
            <Info title="Customer-controlled changes">
              Reschedule from the live calendar. At 15 minutes waiting, both
              contacts get a reminder; after 30 minutes, an admin ticket opens
              and rescheduling becomes available.
            </Info>
          </>
        )}
        {view === "photos" && (
          <>
            <div className={styles.photos}>
              <button>
                ＋<span>Before-service photos</span>
              </button>
              <button>
                ＋<span>After-service photos</span>
              </button>
            </div>
            <Info title="Quality record">
              OTP start, hygiene checklist, add-ons, upgrade consent, photo
              proof, rating and invoice stay linked to this booking.
            </Info>
          </>
        )}
        {view === "payment" && (
          <article className={styles.qr}>
            <i>▦</i>
            <div>
              <span>
                {pay === "after" ? "PAY AFTER SERVICE" : "PAID ONLINE"}
              </span>
              <h3>{money(total)}</h3>
              <p>
                Groomer may show the Razorpay QR. Payment status, receipt and
                GST invoice go to the primary contact.
              </p>
            </div>
          </article>
        )}
      </section>
    );
  return (
    <section className={styles.flow}>
      <div className={styles.steps}>
        {[1, 2, 3, 4].map((n) => (
          <span key={n} className={step >= n ? styles.active : ""}>
            {n}
          </span>
        ))}
      </div>
      {step === 1 && (
        <>
          <Head title="Who needs grooming?" note="Pets · 1 of 4" />
          <div className={styles.types}>
            {(
              [
                ["dog", "🐕", "Dog"],
                ["cat", "🐈", "Cat"],
                ["puppy", "🐶", "Puppy"],
                ["kitten", "🐱", "Kitten"],
              ] as [PetType, string, string][]
            ).map((t) => (
              <button
                key={t[0]}
                className={type === t[0] ? styles.selected : ""}
                onClick={() => changeType(t[0])}
              >
                <i>{t[1]}</i>
                <b>{t[2]}</b>
              </button>
            ))}
          </div>
          <label className={styles.field}>
            Number of pets
            <select value={count} onChange={(e) => setCount(+e.target.value)}>
              <option value="1">1 pet</option>
              <option value="2">2 pets · bundle savings</option>
              <option value="3">3 pets · 2.5 hours</option>
              <option value="4">4 pets · 4 hours</option>
            </select>
          </label>
          <article className={styles.pet}>
            <i>{type === "cat" || type === "kitten" ? "🐈" : "🐕"}</i>
            <span>
              <b>
                {count === 1
                  ? type === "cat"
                    ? "Coco"
                    : "Bruno"
                  : `${count} ${type}s`}
              </b>
              <small>Profiles, health notes and service history included</small>
            </span>
            <em>✓</em>
          </article>
          <button className={styles.add}>＋ Add or edit pet details</button>
          <p className={styles.hint}>
            Book 1–4 pets. More than 4 opens a PawSpace team enquiry.
          </p>
          <button className={styles.primary} onClick={() => setStep(2)}>
            Choose a package
          </button>
        </>
      )}
      {step === 2 && (
        <>
          <Head
            title={`${type[0].toUpperCase() + type.slice(1)} packages`}
            note="Care · 2 of 4"
          />
          <p className={styles.chooseHelp}>
            Choose by outcome, then check exactly what is included and what
            still needs an add-on.
          </p>
          <div className={styles.packs}>
            {list.map((p) => (
              <button
                key={p.id}
                className={
                  pack.id === p.id && plan === "single" ? styles.selected : ""
                }
                onClick={() => {
                  setPackId(p.id);
                  setPlan("single");
                }}
              >
                <span>{p.badge}</span>
                <h4>{p.name}</h4>
                <p>{p.detail}</p>
                <small className={styles.bestFor}>
                  Best for · {p.bestFor}
                </small>
                <b>
                  {money(bundle(p, count, type))}
                  <small>{count > 1 ? ` · ${count} pets` : ""}</small>
                </b>
              </button>
            ))}
          </div>
          <article className={styles.packageDetail}>
            <header>
              <div>
                <small>SELECTED PACKAGE</small>
                <h4>{pack.name}</h4>
              </div>
              <strong>{money(bundle(pack, count, type))}</strong>
            </header>
            <p>{pack.bestFor}</p>
            <div className={styles.coverage}>
              <section>
                <b>✓ Included</b>
                {pack.includes.map((item) => (
                  <span key={item}>✓ {item}</span>
                ))}
              </section>
              <section className={styles.notIncluded}>
                <b>Not included</b>
                {pack.missing.map((item) => (
                  <span key={item}>— {item}</span>
                ))}
              </section>
            </div>
            {pack.id === "complete" && (
              <small className={styles.completeNote}>
                Complete means all core grooming and styling. Tick & flea care
                and oil massage remain optional add-ons.
              </small>
            )}
          </article>
          <div className={styles.compareStrip}>
            <b>Quick comparison</b>
            <span>
              <i />
              <i>Bath</i>
              <i>Hygiene</i>
              <i>Haircut</i>
            </span>
            {list.map((item) => (
              <span key={item.id}>
                <strong>
                  {item.name.replace("Complete Makeover", "Complete")}
                </strong>
                <i>{item.missing.some((x) => /bath/i.test(x)) ? "—" : "✓"}</i>
                <i>
                  {item.includes.some((x) => /hygiene|nail|routine/i.test(x))
                    ? "✓"
                    : "—"}
                </i>
                <i>
                  {item.includes.some((x) =>
                    /full-body haircut|full-body trim/i.test(x),
                  )
                    ? "✓"
                    : "—"}
                </i>
              </span>
            ))}
          </div>
          {(type === "dog" || type === "cat") && (
            <>
              <Title title="Subscription wallet" note="Book now or later" />
              <div className={styles.subs}>
                {subs.map((s) => {
                  const sessions = s.id === "trim3" ? 3 : Number.parseInt(s.id);
                  const planPrice = subscriptionPrice(s.id, type, s.price);
                  const singleReference = s.id === "trim3"
                    ? 1599
                    : type === "dog"
                      ? packages.dog[0].price
                      : packages.cat[0].price;
                  const perSession = Math.round(planPrice / sessions);
                  const saving = Math.max(0, singleReference * sessions - planPrice);
                  return (
                  <button
                    key={s.id}
                    className={plan === s.id ? styles.selected : ""}
                    onClick={() => {
                      setPlan(s.id);
                      setPackId(s.id === "trim3" ? "trim" : type === "dog" ? "bath" : "routine");
                    }}
                  >
                    <b>{s.name}</b>
                    <strong>
                      {money(planPrice * count)}
                    </strong>
                    <small>{money(perSession)} / pet / session · GST included</small>
                    <em>Save {money(saving)} per pet vs {sessions} single sessions</em>
                    <small>Valid {s.validity}</small>
                  </button>
                  );
                })}
              </div>
              <p className={styles.hint}>
                Session plans keep the selected package scope. Trimming or
                styling is included only when the chosen package says so.
              </p>
            </>
          )}
          <Title title="Add-ons" note="Optional · not part of Complete" />
          <div className={styles.addons}>
            {[
              ["Tick & flea treatment", 499],
              ["Full-body oil massage", 299],
            ].map((a) => (
              <button
                key={a[0]}
                className={addons.includes(String(a[0])) ? styles.selected : ""}
                onClick={() => toggle(String(a[0]))}
              >
                {addons.includes(String(a[0])) ? "✓" : "＋"} {a[0]}{" "}
                <b>{money(+a[1])}</b>
              </button>
            ))}
          </div>
          <button className={styles.back} onClick={() => setStep(1)}>
            ← Pets
          </button>
          <button className={styles.primary} onClick={() => setStep(3)}>
            Check live availability
          </button>
        </>
      )}
      {step === 3 && (
        <>
          <Head title="Choose a live slot" note="Calendar · 3 of 4" />
          <Info title={duration}>
            Extra time is protected for multi-pet care and approved upgrades.
          </Info>
          <div className={styles.dates}>
            {dates.map((d) => (
              <button
                key={d}
                className={date === d ? styles.selected : ""}
                onClick={() => setDate(d)}
              >
                {d}
              </button>
            ))}
          </div>
          <div className={styles.slots}>
            {slots.map((s, i) => (
              <button
                key={s}
                disabled={!i}
                className={slot === s ? styles.selected : ""}
                onClick={() => setSlot(s)}
              >
                <b>{s}</b>
                <small>
                  {!i
                    ? "Full"
                    : i % 2
                      ? "2 groomers available"
                      : "1 groomer available"}
                </small>
              </button>
            ))}
          </div>
          <label className={styles.check}>
            <input
              type="checkbox"
              checked={preferred}
              onChange={(e) => setPreferred(e.target.checked)}
            />
            <span>
              <b>Prefer Arun R.</b>
              <small>Same groomer when his calendar is available</small>
            </span>
          </label>
          <p className={styles.hint}>
            All Bengaluru pincodes are covered. Availability comes from groomer
            calendars.
          </p>
          <button className={styles.back} onClick={() => setStep(2)}>
            ← Package
          </button>
          <button className={styles.primary} onClick={() => setStep(4)}>
            Review booking
          </button>
        </>
      )}
      {step === 4 && (
        <>
          <Head title="Review and confirm" note="OTP · 4 of 4" />
          <article className={styles.review}>
            <span>
              Care<b>{summary}</b>
            </span>
            <span>
              Schedule
              <b>
                {date} · {slot}
              </b>
            </span>
            <span>
              Duration<b>{duration}</b>
            </span>
            <span>
              Groomer
              <b>
                {preferred
                  ? "Arun R. preferred · auto-backup"
                  : "Best available · auto-assigned"}
              </b>
            </span>
            <span>
              Primary<b>Karthik · +91 99••• 99505</b>
            </span>
            <span>
              Secondary<b>Rahul · +91 98••• 22741</b>
            </span>
          </article>
          <div className={styles.pay}>
            {[
              ["after", "Pay after service", "QR or link after completion"],
              ["online", "Pay online", "Protected Razorpay checkout"],
            ].map((p) => (
              <button
                key={p[0]}
                className={pay === p[0] ? styles.selected : ""}
                onClick={() => setPay(p[0])}
              >
                <b>{p[1]}</b>
                <span>{p[2]}</span>
              </button>
            ))}
          </div>
          <CouponField
            service="Grooming"
            orderValue={subtotal}
            customerKind={sub ? "subscriber" : "existing"}
            isSubscription={Boolean(sub)}
            paymentMode={pay === "online" ? "full" : "after_service"}
            onDiscountChange={(value, code) => {
              setDiscount(value);
              setCouponCode(code);
            }}
          />
          <article className={styles.total}>
            {discount > 0 && <span>Coupon saving<b>−{money(discount)}</b></span>}
            <span>
              Total incl. all charges<b>{money(total)}</b>
            </span>
            <small>
              Coupon, GST invoice and PawPoints use the same customer record.
            </small>
          </article>
          <p className={styles.hint}>
            OTP is requested only now. Confirmation goes to both contacts.
          </p>
          <button className={styles.back} onClick={() => setStep(3)}>
            ← Slot
          </button>
          <button className={styles.primary} onClick={confirm} disabled={scheduling}>
            {scheduling ? "Reserving groomer…" : "Verify OTP & confirm instantly"}
          </button>
          {scheduleError && <p role="alert">{scheduleError}</p>}
        </>
      )}
    </section>
  );
}
function Head({ title, note }: { title: string; note: string }) {
  return (
    <div className={styles.head}>
      <h3>{title}</h3>
      <small>{note}</small>
    </div>
  );
}
function Title({ title, note }: { title: string; note: string }) {
  return (
    <div className={styles.section}>
      <b>{title}</b>
      <span>{note}</span>
    </div>
  );
}
function Info({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <article className={styles.info}>
      <b>{title}</b>
      <span>{children}</span>
    </article>
  );
}
